import java.awt.event.*;
import java.util.ArrayList;
import java.util.Stack;
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.ActionEvent;
import java.io.*;
import javax.imageio.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
public class PaintProgram extends JPanel implements ActionListener, MouseMotionListener, AdjustmentListener, MouseListener, ChangeListener{
    private ArrayList<ArrayList<Point>> lines;
    private ArrayList<Point> points;
    private ArrayList<Shape> shapes;
    private Stack<Shape> undoShapes;
    private Stack<ArrayList<Point>> undoLines;
    private Stack<String> commandOrder;
    private Stack<String> undoCommandOrder;
    JFrame frame;
    JMenuBar bar;
    JMenu color, file;
    JMenuItem[] options;
    JMenuItem save, load;
    JScrollBar penWidth;
    JLabel pen;
    Color current = Color.WHITE;
    Color[] colors;
    int currentWidth = 3;
    JButton freeLine, rectangle, undo, redo;
    boolean free = true, rect = false; 
    JColorChooser colorChooser;
    ImageIcon lineImage, rectImage, undoImage, redoImage;
    JFileChooser fileChooser;
    BufferedImage loadedImage;
    public PaintProgram(){
        lines = new ArrayList<>();
        points = new ArrayList<>();
        shapes = new ArrayList<>();
        undoShapes = new Stack<>();
        undoLines = new Stack<>();
        commandOrder = new Stack<>();
        undoCommandOrder = new Stack<>();
        frame = new JFrame("Paint Program");
        frame.add(this);
        this.addMouseMotionListener(this);
        this.addMouseListener(this);
        frame.setSize(1000,600);
        bar = new JMenuBar();
        color = new JMenu("Color");
        colors = new Color[]{Color.WHITE, Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.BLUE, Color.PINK};
        options = new JMenuItem[7];
        color.setLayout(new GridLayout(1,7));
        for(int i = 0; i < 7; i++){
            options[i] = new JMenuItem();
            options[i].setPreferredSize(new Dimension(80,40));
            options[i].addActionListener(this);
            options[i].putClientProperty("colorIndex", i);
            options[i].setBackground(colors[i]);
            color.add(options[i]);
        }
        colorChooser = new JColorChooser();
        colorChooser.getSelectionModel().addChangeListener(this);
        color.add(colorChooser);
        file = new JMenu("File");
        save = new JMenuItem("Save");
        load = new JMenuItem("Load");
        save.addActionListener(this);
        load.addActionListener(this);
        file.add(save);
        file.add(load);
        bar.add(file);
        bar.add(color);
        frame.setJMenuBar(bar);
        lineImage = new ImageIcon("squiggle.png");
        rectImage = new ImageIcon("rectangle.png");
        undoImage = new ImageIcon("undo.png");
        redoImage = new ImageIcon("redo.png");
        penWidth = new JScrollBar(JScrollBar.HORIZONTAL, 0, 0, 0, 200);
        penWidth.addAdjustmentListener(this);
        penWidth.setValue(currentWidth);
        freeLine = new JButton(lineImage);
        freeLine.setFocusPainted(false);
        rectangle = new JButton(rectImage);
        rectangle.setFocusPainted(false);
        undo = new JButton(undoImage);
        undo.setFocusPainted(false);
        redo = new JButton(redoImage);
        redo.setFocusPainted(false);
        freeLine.addActionListener(this);
        rectangle.addActionListener(this);
        undo.addActionListener(this);
        redo.addActionListener(this);
        bar.add(freeLine);
        bar.add(rectangle);
        bar.add(undo);
        bar.add(redo);
        bar.add(penWidth);

        String currDir = System.getProperty("user.dir");
        fileChooser = new JFileChooser(currDir);


        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, frame.getWidth(), frame.getHeight());
    
        if(loadedImage != null){
            g.drawImage(loadedImage,0,0,null);
        }
        for(ArrayList<Point> p: lines){
            for(int i = 1; i < p.size(); i++){
                g.setColor(p.get(i).getColor());
                g2.setStroke(new BasicStroke(p.get(i).getWidth()));
                g.drawLine(p.get(i-1).getX(), p.get(i-1).getY(), p.get(i).getX(), p.get(i).getY());
            }
        }
        if(free){
           for(int i = 1; i < points.size(); i++){
                g.setColor(points.get(i).getColor());
                g2.setStroke(new BasicStroke(points.get(i).getWidth()));
                g.drawLine(points.get(i-1).getX(), points.get(i-1).getY(), points.get(i).getX(), points.get(i).getY());
            } 
        }
        for(Shape s: shapes){
            g.setColor(s.getColor());
            g2.setStroke(new BasicStroke(s.getPenWidth()));
            g.drawRect(s.getX(), s.getY(), s.getWidth(), s.getHeight());
        }
        if(rect){
            if(points.size() > 0){
                Point start = points.get(0);
                Point end = points.get(points.size() - 1);
                int x, y, height, width;
                if (start.getX() > end.getX()) {
                    x = end.getX();
                    width = start.getX() - end.getX();
                } else {
                    x = start.getX();
                    width = end.getX() - start.getX();
                }
                if (start.getY() < end.getY()) {
                    y = start.getY();
                    height = end.getY() - start.getY();
                } else {
                    y = end.getY();
                    height = start.getY() - end.getY();
                }
                g.setColor(start.getColor());
                g2.setStroke(new BasicStroke(start.getWidth()));
                g.drawRect(x, y, width, height);
            }
            
        }
        
    }
    public void actionPerformed(ActionEvent e){
        for(int i = 0; i < options.length; i++){
           if(e.getSource() == options[i]) {
               int index = Integer.parseInt("" + ((JMenuItem) e.getSource()).getClientProperty("colorIndex"));
               current = colors[index];
           }
        }
        if(e.getSource() == freeLine){
            free = true;
            rect = false;
        }
        if(e.getSource() == rectangle){
            free = false;
            rect = true;
        }
        if(e.getSource() == undo){
            if(commandOrder.size() > 0){
                String last = commandOrder.pop();
                undoCommandOrder.push(last);
                if(last.equals("freeLine")){
                    if(lines.size() > 0){
                        undoLines.push(lines.remove(lines.size()-1));
                    }
                }
                if(last.equals("rect")){
                    if(shapes.size() > 0){
                        undoShapes.push(shapes.remove(shapes.size()-1));
                    }
                }
            }
            repaint();
        }
        if(e.getSource() == redo){
            if(undoCommandOrder.size() > 0){
                String recent = undoCommandOrder.pop();
                commandOrder.push(recent);
                if(recent.equals("freeLine")){
                    lines.add(undoLines.pop());
                }
                if(recent.equals("rect")){
                    shapes.add(undoShapes.pop());
                }
            }
            repaint();
        }
        if(e.getSource() == save){
            FileFilter filter = new FileNameExtensionFilter("*.png", "png");
            fileChooser.setFileFilter(filter);
            if(fileChooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION){
                File file = fileChooser.getSelectedFile();
                try{
                    ImageIO.write(createImage(),"png", new File(file.getAbsolutePath()+".png"));
                }catch(IOException exc){

                }
            }
        }
        if(e.getSource() == load){
            fileChooser.showOpenDialog(null);
            File imgFile = fileChooser.getSelectedFile();
            try{
                loadedImage = ImageIO.read(imgFile);
            }catch(IOException exc){

            }
            if(loadedImage != null){
                lines = new ArrayList<>();
                points = new ArrayList<>();
                shapes = new ArrayList<>();
                undoShapes = new Stack<>();
                undoLines = new Stack<>();
                commandOrder = new Stack<>();
                undoCommandOrder = new Stack<>();
            }
            
            repaint();
        }

        
    }
    public void adjustmentValueChanged(AdjustmentEvent e){
        if(e.getSource() == penWidth){
            currentWidth = penWidth.getValue()/10;
            if(currentWidth == 0){
                currentWidth++;
            }
        }
    }
    public void mouseDragged(MouseEvent e){
        points.add(new Point(e.getX(), e.getY(), current, currentWidth));
        repaint();
    }
    public void mouseMoved(MouseEvent e){

    }
    public void mousePressed(MouseEvent e){

    }
    public void mouseReleased(MouseEvent e){
        if(free){
            lines.add(points);
            commandOrder.push("freeLine");
        }
        if(rect){
            Point start = points.get(0);
            Point end = points.get(points.size()-1);
            int x, y, height, width;
            if(start.getX()>end.getX()){
                x = end.getX();
                width = start.getX() - end.getX();
            }else{
                x = start.getX();
                width = end.getX() - start.getX();
            }
            if(start.getY() < end.getY()){
                y = start.getY();
                height = end.getY() - start.getY();
            }else{
                y = end.getY();
                height = start.getY() - end.getY();
            }
            shapes.add(new Shape(x, y, width, height, current, currentWidth));
            commandOrder.push("rect");
        }
            
        points = new ArrayList<Point>();
        repaint();
    }
    public void mouseEntered(MouseEvent e){

    }
    public void mouseExited(MouseEvent e){

    }
    public void mouseClicked(MouseEvent e){

    }
    public void stateChanged(ChangeEvent e){
        current = colorChooser.getColor();
    }
    public BufferedImage createImage(){
        int width = this.getWidth();
        int height = this.getHeight();
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = image.createGraphics();
        this.paint(g2);
        g2.dispose();
        return image;
    }

    public class Point{
     private int x, y;
     private int width;
     Color color;
     public Point(int x, int y, Color color, int width){
         this.x = x;
         this.y = y;
         this.color = color;
         this.width = width;
     }   
     public int getX(){
         return x;
     }
     public int getY(){
         return y;
     }
     public Color getColor(){
         return color;
     }
     public int getWidth(){
         return width;
     }
    }
    public class Shape{
        private int x, y, height, width;
        Color color;
        private int penWidth;
        public Shape(int x, int y, int width, int height, Color color, int penWidth){
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.color = color;
            this.penWidth = penWidth;
        }
        public int getX(){
            return x;
        }
        public int getY(){
            return y;
        }
        public Color getColor(){
            return color;
        }
        public int getWidth(){
            return width;
        }
        public int getHeight(){
            return height;
        }
        public void setWidth(int width){
            this.width = width;
        }
        public void setHeight(int height){
            this.height = height;
        }
        public int getPenWidth(){
            return penWidth;
        }
    }
    public static void main(String[] args){
        PaintProgram run = new PaintProgram();
    }
}